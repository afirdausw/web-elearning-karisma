<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        //check user session

        //load library in construct. Construct method will be run everytime the controller is called
        //This library will be auto-loaded in every method in this controller.
        //So there will be no need to call the library again in each method.
        //$this->load->library(array('PHPExcel', 'PHPExcel/IOFactory'));
        $this->load->library('form_validation');
        $this->load->helper('alert_helper');
        $this->load->model('model_adm');
        $this->load->model('model_security');
        $this->load->model('model_pg');
        $this->load->model('model_psep');
        $this->model_security->is_logged_in();

    }

    public function index()
    {
        $data = array(
            'navbar_title' => "Siswa",
            'form_action' => base_url() . $this->uri->slash_segment(1) . $this->uri->slash_segment(2),
            'table_data' => $this->model_adm->fetch_all_siswa()
        );



        $this->load->view('pg_admin/siswa', $data);
    }

    public function upload()
    {
        // $fileName = time().$_FILES['file']['name'];

        // $config['upload_path'] = './assets/'; //buat folder dengan nama assets di root folder
        // $config['file_name'] = $fileName;
        // $config['allowed_types'] = 'xls|xlsx|csv';
        // $config['max_size'] = 10000;

        // $this->load->library('upload', $config);

        // $this->load->library('upload');
        // $this->upload->initialize($config);


        // //if(!$this->upload->do_upload('file')) {
        //     $this->upload->display_errors();
        // //} 
        // $media = $this->upload->data('file');
        // $inputFileName = './assets/'.$media['file_name'];

        // try {
        //     $inputFileType = IOFactory::identify($inputFileName);
        //     $objReader = IOFactory::createReader($inputFileType);
        //     $objPHPExcel = $objReader->load($inputFileName);
        // } catch(Exception $e) {
        //     die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
        // }

        // $sheet = $objPHPExcel->getSheet(0);
        // $highestRow = $sheet->getHighestRow();
        // $highestColumn = $sheet->getHighestColumn();

        // for ($row = 2; $row <= $highestRow; $row++){                  //  Read a row of data into an array
        //     $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
        //         NULL,
        //         TRUE,
        //         FALSE);

        //     //Sesuaikan sama nama kolom tabel di database
        //     $data = array(
        //         "nama_siswa"=> $rowData[0][0],
        //         "alamat"    => $rowData[0][1],
        //         "telepon"  => $rowData[0][2],
        //     );

        //     //sesuaikan nama dengan nama tabel
        //     $insert = $this->db->insert("siswa",$data);
        //     delete_files($media['file_path']);

        // }
        // redirect('pg_admin/siswa');

//        $config['upload_path'] = './temp_upload/';
//        //$config['allowed_types'] = 'xls';
//        $config['allowed_types'] = 'xls|xlsx|csv';

//        echo "disini";
//
//		$this->load->library('upload', $config);
//
//		if ( ! $this->upload->do_upload())
//		{
//			$data = array('error' => $this->upload->display_errors());
//
//		}
//		else
//		{
//
//            $data = array('error' => false);
//			$upload_data = $this->upload->data();
//
//            $this->load->library('excel_reader');
//			$this->excel_reader->setOutputEncoding('CP1251');
//
//			$file =  $upload_data['full_path'];
//			$this->excel_reader->read($file);
//			error_reporting(E_ALL ^ E_NOTICE);
//
//			// Sheet 1
//			$data = $this->excel_reader->sheets[0] ;
//                        $dataexcel = Array();
//			for ($i = 1; $i <= $data['numRows']; $i++) {
//
//                            if($data['cells'][$i][1] == '') break;
//                            $dataexcel[$i-1]['nama_siswa'] = $data['cells'][$i][1];
//                            $dataexcel[$i-1]['alamat'] = $data['cells'][$i][2];
//
//			}
//
//            delete_files($upload_data['file_path']);
//            $this->load->model('User_model');
//            $this->User_model->tambahuser($dataexcel);
//            $data['user'] = $this->User_model->getuser();
//		}
//        //$this->load->view('pg_admin/siswa', $data);
//        //redirect('pg_admin/siswa');
        //Path of files were you want to upload on localhost (C:/xampp/htdocs/ProjectName/uploads/excel/)
//        $configUpload['upload_path'] = FCPATH . 'uploads/excel/';
//        $configUpload['allowed_types'] = 'xls|xlsx|csv';
//
//        $configUpload['max_size'] = '5000';
//        $this->load->library('upload', $configUpload);
//        $this->upload->do_upload('userfile');
//        $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
//        $file_name = $upload_data['file_name']; //uploded file name
//        $extension = $upload_data['file_ext'];    // uploded file extension
//
//        $objReader = PHPExcel_IOFactory::createReader('Excel5');     //For excel 2003
//        //$objReader= PHPExcel_IOFactory::createReader('Excel2007');	// For excel 2007
//        //Set to read only
//        $objReader->setReadDataOnly(true);
//        //Load excel file
//        $objPHPExcel = $objReader->load(FCPATH . 'uploads/excel/' . $file_name);
//        $totalrows = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();   //Count Numbe of rows avalable in excel
//        $objWorksheet = $objPHPExcel->setActiveSheetIndex(0);
//        //loop from first data untill last data
//        for ($i = 2; $i <= $totalrows; $i++) {
//            $FirstName = $objWorksheet->getCellByColumnAndRow(0, $i)->getValue();
//            $Address = $objWorksheet->getCellByColumnAndRow(4, $i)->getValue(); //Excel Column 4
//            $Email = $objWorksheet->getCellByColumnAndRow(2, $i)->getValue(); //Excel Column 2
//            $Mobile = $objWorksheet->getCellByColumnAndRow(3, $i)->getValue(); //Excel Column 3
//            $data_user = array('nama_siswa' => $FirstName, 'alamat' => $Address, 'telepon' => $Email, 'email' => $Mobile);
//            $this->excel_data_insert_model->Add_User($data_user);
//
//
//        }
//        //unlink('././uploads/excel/'.$file_name); //File Deleted After uploading in database .
//        //redirect(base_url() . "put link were you want to redirect");

        $data = array(
            'navbar_title'		=> "Manajemen Sekolah",
            'page_title' 			=> "Import Data Sekolah",
            'form_action' 		=> current_url()
        );

        $data = array(
            'page_title' => "Import Data Sekolah",
            'form_action' => current_url()
        );

        $this->upload_config();

        if (!$this->upload->do_upload('import_data')) {
            $errors = array('error' => $this->upload->display_errors());
            alert_error("Error", "Proses import data gagal");
            //$this->load->view('pg_admin/siswa', $data);
            redirect('pg_admin/siswa');
            //echo "prosses upload gagal";
        } else {
            $this->load->library(array('PHPExcel', 'PHPExcel/IOFactory'));

            $media = $this->upload->data();
            $data_sekolah = array();
            $inputFileName = 'assets/uploads/excel_files/' . $media['file_name'];

            try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch (Exception $e) {
                die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
            }

            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();

            for ($row = 2; $row <= $highestRow; $row++) { //  Read a row of data into an array
                $rowData = $sheet->rangeToArray(
                    'A' . $row . ':' . $highestColumn . $row,
                    NULL,
                    TRUE,
                    FALSE
                );
                //Sesuaikan dengan nama kolom tabel di database
                if (!empty($rowData[0][0]) && !empty($rowData[0][1])) {
                    $data_sekolah[] = array(
                        "nama_siswa" => $rowData[0][0],
                        "alamat" => strtoupper($rowData[0][1]),
                        "telepon" => $rowData[0][2],
                        "email" => $rowData[0][3]

                    );
                }

            }

            $import = $this->model_adm->import_siswa($data_sekolah);
            if ($import) {
                alert_success('Sukses', "Data berhasil diimport!");
            }
            redirect('pg_admin/siswa');
            // echo "<pre>";
            // echo print_r($data_sekolah);
            // echo "</pre>";
            // die();
            //
            // delete_files($media['file_path']);

        }

    }

    private function upload_config()
    {
        // $fileName = date("dmy_Hi")."_".$_FILES['import_data']['name'];
        $fileName = 'latest_upload';
        $config['upload_path'] = 'assets/uploads/excel_files';
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
        $config['overwrite'] = TRUE;

        $this->load->library('upload');
        $this->upload->initialize($config);
    }

    public function pendaftar()
    {
        $data = array(
            'navbar_title' => "Pendaftar",
            'form_action' => base_url() . $this->uri->slash_segment(1) . $this->uri->slash_segment(2),
            'table_data' => $this->model_adm->fetch_siswa_pendaftar(),
            'select_provinsi' => $this->model_pg->fetch_all_provinsi(),
            'select_kota'     => $this->model_pg->fetch_all_kota(),
            'select_sekolah'  => $this->model_pg->fetch_all_sekolah(),
            'select_kelas'    => $this->model_pg->fetch_all_kelas(),
            'select_jenjang'  => $this->model_pg->fetch_options_jenjang(),
        );

        $this->load->view('pg_admin/siswa_pendaftar', $data);
    }

    function kota($idprovinsi)
    {
        $carikota = $this->model_signup->get_kota_by_provinsi($idprovinsi);

        foreach ($carikota as $kota) {
            echo "
			<option value='$kota->id_kota'>$kota->nama_kota</option>
		";
        }
    }


    function sekolah($idkota)
    {
        $carisekolah = $this->model_signup->get_sekolah_by_kota($idkota);

        echo "
		<option value=''>Pilih Sekolah...</option>
	";
        foreach ($carisekolah as $sekolah) {
            echo "
			<option value='$sekolah->id_sekolah'>$sekolah->nama_sekolah</option>
		";
        }
    }

    function kelas($idsekolah)
    {
        if ($idsekolah !== 'sekolahbaru') {
            $carijenjang = $this->model_signup->cari_jenjang($idsekolah);

            $carikelas = $this->model_signup->cari_kelas_by_jenjang($carijenjang->jenjang);

            foreach ($carikelas as $kelas) {
                echo "
				<option value='$kelas->id_kelas'>$kelas->alias_kelas</option>
			";
            }
        }
    }

    function ajax_siswa_by_jenjang($kelas,$sekolah){
        //$idsekolah = $this->session->userdata('idsekolah');

        $carisiswa = $this->model_psep->cari_siswa_by_kelas($kelas, $sekolah);


        $no = 1;
        foreach($carisiswa as $siswa){
            ?>
            <tr>
                <td><?php echo $no;?></td>
                <td><?php echo $siswa->nama_siswa;?></td>
                <td><?php echo $siswa->alias_kelas;?></td>
                <td><?php echo $siswa->email;?></td>
                <td><?php echo $siswa->telepon;?></td>
                <td><?php echo $siswa->telepon_ortu;?></td>

            </tr>
            <?php
            $no++;
        }
    }

    public function aktif()
    {
        $data = array(
            'navbar_title' => "Siswa Aktif",
            'form_action' => base_url() . $this->uri->slash_segment(1) . $this->uri->slash_segment(2),
            'table_data' => $this->model_adm->fetch_siswa_aktif()
        );

        $this->load->view('pg_admin/siswa_aktif', $data);
    }

    public function manajemen($aksi)
    {
        //$aksi contains the value needed (tambah/ubah) to direct user to Add/Edit form
        if ($aksi) {
            //Trigger form submission validation rules
            $this->form_validation_rules();

            switch ($aksi) {
                case 'tambah':
                    $data = array(
                        'navbar_title' => "Manajemen Siswa",
                        'page_title' => "Tambah Siswa",
                        'form_action' => current_url(),
                        'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
                        'select_options' => $this->model_adm->fetch_all_kelas(),
                        'select_jenjang' => $this->model_adm->fetch_options_jenjang(),
                        'select_provinsi' => $this->model_adm->fetch_options_provinsi(),
                        'select_kota' => $this->model_adm->fetch_options_kota()
                    );

                    //Form materi submit handler. See if the user is attempting to submit a form or not
                    if ($this->input->post('form_submit')) {
                        //Form is submitted. Now routing to proses_tambah method
                        $this->proses_tambah();
                    } else {
                        //No form is submitted. Displaying the form page
                        $this->load->view('pg_admin/siswa_form', $data);
                    }
                    break;

                case 'ubah':
                    //Passing id value from GET '?id' to variable '$id'
                    $id = $this->input->get('id') ? $this->input->get('id') : null;

                    $data = array(
                        'navbar_title' => "Manajemen Siswa",
                        'page_title' => "Ubah Siswa",
                        'form_action' => current_url() . "?id=$id",
                        'data_siswa' => $this->model_adm->fetch_siswa_by_id($id),
                        'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
                        'select_options' => $this->model_adm->fetch_all_kelas()
                    );

                    //Redirect to siswa if id is not exist
                    if (!$id) {
                        redirect('pg_admin/siswa');
                    } else {
                        //Calling values from database by id and pass them to View
                        //fetching siswa by id
                        $data['data'] = $this->fetch_siswa_by_id($id);

                        //Form submit handler. See if the user is attempting to submit a form or not
                        if ($this->input->post('form_submit')) {
                            //Form is submitted. Now routing to proses_tambah method
                            $this->proses_ubah($id);
                        } else {
                            //No form is submitted. Displaying the form page
                            $this->load->view('pg_admin/siswa_form', $data);
                        }
                    }
                    break;

                case 'ubah_aktif':
                    //Passing id value from GET '?id' to variable '$id'
                    $id = $this->input->get('id') ? $this->input->get('id') : null;

                    $data = array(
                        'navbar_title' => "Manajemen Siswa",
                        'page_title' => "Ubah Siswa",
                        'form_action' => current_url() . "?id=$id",
                        'data_siswa' => $this->model_adm->fetch_siswa_by_id($id),
                        'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
                        'select_options' => $this->model_adm->fetch_all_kelas()
                    );

                    //Redirect to siswa if id is not exist
                    if (!$id) {
                        redirect('pg_admin/siswa');
                    } else {
                        //Calling values from database by id and pass them to View
                        //fetching siswa by id
                        $data['data'] = $this->fetch_siswa_by_id($id);

                        //Form submit handler. See if the user is attempting to submit a form or not
                        if ($this->input->post('form_submit')) {
                            //Form is submitted. Now routing to proses_tambah method
                            $this->proses_ubah_aktif($id);
                        } else {
                            //No form is submitted. Displaying the form page
                            $this->load->view('pg_admin/siswa_form', $data);
                        }
                    }
                    break;

                default:
                    redirect('pg_admin/siswa');
                    break;
            }
        } else {
            redirect('pg_admin/siswa');
        }

    }

    public function proses_tambah()
    {
        //set the page title
        $data = array(
            'page_title' => "Pendaftaran Siswa",
            'form_action' => current_url(),
            'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
            'select_options' => $this->model_adm->fetch_all_kelas()
        );

        //fetch input (make sure that the variable name is the same as column name in database!)
        $params = $this->input->post(null, true);
        $nama = $params['nama'] ? $params['nama'] : '';
        $email = $params['email'] ? $params['email'] : '';
        $telepon = $params['telepon'] ? $params['telepon'] : '';
        $telepon_ortu = $params['telepon_ortu'] ? $params['telepon_ortu'] : '';
        $alamat = $params['alamat'] ? $params['alamat'] : '';
        $sekolah_id = $params['sekolah'] ? $params['sekolah'] : '';
        $kelas = $params['kelas'] ? $params['kelas'] : '';
        //$tambah_sekolah	= $params['tambah_sekolah'] ? $params['tambah_sekolah'] : null;

        if (!empty($tambah_sekolah)) {
            $jenjang = $this->model_adm->fetch_kelas_by_id($kelas)->jenjang;
            $insert_id = $this->model_adm->add_quick_sekolah($tambah_sekolah, $jenjang);
            $sekolah_id = $insert_id;
        }

        //run the validation
        if ($this->form_validation->run() == FALSE) {
            alert_error("Error", "Data gagal ditambahkan");
            $this->load->view('pg_admin/siswa_form', $data);
        } else {
            //passing input value to Model
            $result = $this->model_adm->add_siswa($nama, $email, $telepon, $telepon_ortu, $alamat, $sekolah_id, $kelas);
            alert_success("Sukses", "Data berhasil ditambahkan");
            redirect('pg_admin/siswa');
            // echo "Status Insert: " . $result;
        }
    }

    public function proses_ubah($id)
    {
        //set the page title
        $data = array(
            'page_title' => "Ubah Data Siswa",
            'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
            'select_options' => $this->model_adm->fetch_all_kelas(),
            'form_action' => current_url() . "?id=$id"
        );

        //fetch input (make sure that the variable name is the same as column name in database!)
        $params = $this->input->post(null, true);
        $nama = $params['nama'] ? $params['nama'] : '';
        $email = $params['email'] ? $params['email'] : '';
        $telepon = $params['telepon'] ? $params['telepon'] : '';
        $telepon_ortu = $params['telepon_ortu'] ? $params['telepon_ortu'] : '';
        $alamat = $params['alamat'] ? $params['alamat'] : '';
        $sekolah_id = $params['sekolah'] ? $params['sekolah'] : '';
        $kelas = $params['kelas'] ? $params['kelas'] : '';
        //$tambah_sekolah	= $params['tambah_sekolah'] ? $params['tambah_sekolah'] : null;

        if (!empty($tambah_sekolah)) {
            $jenjang = $this->model_adm->fetch_kelas_by_id($kelas)->jenjang;
            $insert_id = $this->model_adm->add_quick_sekolah($tambah_sekolah, $jenjang);
            $sekolah_id = $insert_id;
        }

        //run the validation
        if ($this->form_validation->run() == FALSE) {
            alert_error("Error", "Data gagal diubah");
            $this->load->view('pg_admin/siswa_form', $data);
        } else {
            //passing input value to Model
            $result = $this->model_adm->update_siswa($id, $nama, $email, $telepon, $telepon_ortu, $alamat, $sekolah_id, $kelas);
            alert_success("Sukses", "Data berhasil diubah");
            redirect('pg_admin/siswa');
            // echo "Status Update: " . $result;
        }
    }

    public function proses_ubah_aktif($id)
    {
        //set the page title
        $data = array(
            'page_title' => "Ubah Data Siswa",
            'select_sekolah' => $this->model_adm->fetch_all_sekolah(),
            'select_options' => $this->model_adm->fetch_all_kelas(),
            'form_action' => current_url() . "?id=$id"
        );

        //fetch input (make sure that the variable name is the same as column name in database!)
        $params = $this->input->post(null, true);
        $nama = $params['nama'] ? $params['nama'] : '';
        $email = $params['email'] ? $params['email'] : '';
        $telepon = $params['telepon'] ? $params['telepon'] : '';
        $telepon_ortu = $params['telepon_ortu'] ? $params['telepon_ortu'] : '';
        $alamat = $params['alamat'] ? $params['alamat'] : '';
        $sekolah_id = $params['sekolah'] ? $params['sekolah'] : '';
        $kelas = $params['kelas'] ? $params['kelas'] : '';
        //$tambah_sekolah	= $params['tambah_sekolah'] ? $params['tambah_sekolah'] : null;

        if (!empty($tambah_sekolah)) {
            $jenjang = $this->model_adm->fetch_kelas_by_id($kelas)->jenjang;
            $insert_id = $this->model_adm->add_quick_sekolah($tambah_sekolah, $jenjang);
            $sekolah_id = $insert_id;
        }

        //run the validation
        if ($this->form_validation->run() == FALSE) {
            alert_error("Error", "Data gagal diubah");
            $this->load->view('pg_admin/siswa_form', $data);
        } else {
            //passing input value to Model
            $result = $this->model_adm->update_siswa($id, $nama, $email, $telepon, $telepon_ortu, $alamat, $sekolah_id, $kelas);
            alert_success("Sukses", "Data berhasil diubah");
            redirect('pg_admin/siswa/aktif');
            // echo "Status Update: " . $result;
        }
    }

    public function proses_hapus()
    {

        if ($this->input->post('deleteRow_submit')) {
            //set form validation rules
            $this->form_validation->set_rules('hidden_row_id', "Nomor Baris", 'trim|required|numeric');

            if ($this->form_validation->run()) {
                $id = $this->input->post('hidden_row_id');
                $result = $this->model_adm->delete_siswa($id);

                alert_success('Sukses', "Data berhasil dihapus");
                redirect('pg_admin/siswa');
            }
        }

        alert_danger('Error', "Data gagal dihapus");
        redirect('pg_admin/siswa');
    }

    private function form_validation_rules()
    {
        //set validation rules for each input
        $this->form_validation->set_rules('nama', 'Nama Siswa', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('telepon', 'Telepon', 'trim|numeric|required');
        $this->form_validation->set_rules('telepon_ortu', 'Telepon Orang Tua', 'trim|numeric|required');
        $this->form_validation->set_rules('kelas', 'Kelas', 'trim|required');
        // $this->form_validation->set_rules('sekolah', 'Sekolah', 'trim|required');
        // $this->form_validation->set_rules('asal_sekolah', 'Asal Sekolah', 'trim|required');

        //set custom error message
        $this->form_validation->set_message('required', '%s tidak boleh kosong');
    }

    private function fetch_siswa_by_id($id)
    {
        $data = new stdClass();
        $table_data = $this->model_adm->fetch_siswa_by_id($id);
        $table_fields = $this->model_adm->get_table_fields('siswa');
        //tester
        // var_dump($table_data);
        // var_dump($table_fields);
        if ($table_data) {
            foreach ($table_fields as $field) {
                $data->{$field} = $table_data->{$field} ? $table_data->{$field} : '';
                // echo "$field -> " . ${$field} . ", ";
            }
        } else {
            $data = null;
        }

        return $data;
    }

    function ajax_select_sekolah()
    {
        $id = $this->input->post('id', true) ? $this->input->post('id', true) : null;
        $id = "ALL"; //remove this if you want to select sekolah by kota

        if ($id) {
            // $dynamic_options = $this->model_pg->fetch_sekolah_by_kota($id);
            $dynamic_options = $this->model_adm->fetch_all_sekolah($id);

            if ($dynamic_options) {
                echo "<option value='' disabled selected>Pilih Sekolah...</option>";
                foreach ($dynamic_options as $item) {
                    echo "<option value='" . $item->id_sekolah . "'> $item->nama_sekolah </option>";
                }
            } else {
                echo "<option value='' disabled='disabled' selected>Data sekolah tidak ditemukan...</option>";
            }
        } else {
            return false;
        }
    }

    function ajax_select_kelas()
    {
        $id = $this->input->post('id', true) ? $this->input->post('id', true) : null;

        if ($id) {
            $sekolah = $this->model_adm->fetch_sekolah_by_id($id);
            $dynamic_options = $this->model_adm->fetch_kelas_by_jenjang($sekolah->jenjang);

            if ($dynamic_options) {
                foreach ($dynamic_options as $item) {
                    echo "<option value=''></option>";
                    echo "<option value='" . $item->id_kelas . "'> $item->alias_kelas </option>";
                }
            } else {
                echo "<option value=''></option>";
                echo "<option value='' disabled='disabled'>Tidak ada data</option>";
            }
        } else {
            return false;
        }
    }

    function ajax_tambah_sekolah()
    {
        $result_id = 0;
        $id_kota = $this->input->post('id_kota');
        $jenjang = $this->input->post('jenjang');
        $sekolah = $this->input->post('sekolah');
        $email = $this->input->post('email');
        $telepon = $this->input->post('telepon');
        $alamat = $this->input->post('alamat');

        if (!empty($id_kota) AND !empty($jenjang) AND !empty($sekolah) AND !empty($email)) {
            //checking if nama sekolah is already exist
            $sekolah_found = $this->model_adm->check_sekolah_by_nama($sekolah);
            if (empty($sekolah_found)) {
                $result_id = $this->model_adm->add_sekolah($sekolah, $jenjang, $email, $telepon, $id_kota, $alamat);
            }
        }
        echo json_encode($result_id);
    }

}
