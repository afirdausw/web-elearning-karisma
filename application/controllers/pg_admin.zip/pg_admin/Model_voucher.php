<?php 

/**
* 
*/
class Model_voucher extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}
	
	
	
	
}